--
-- PostgreSQL database dump
--

\restrict oycNX7ZExLwkfh0x38yKpJgBWhmfDki554FsqrJrFGDJSmoXJeSZL7SHAPBGBIG

-- Dumped from database version 15.14 (Debian 15.14-1.pgdg13+1)
-- Dumped by pg_dump version 15.14 (Debian 15.14-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: public; Owner: mcpuser
--

CREATE FUNCTION public.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_updated_at_column() OWNER TO mcpuser;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: budget_tracking; Type: TABLE; Schema: public; Owner: mcpuser
--

CREATE TABLE public.budget_tracking (
    id integer NOT NULL,
    project_id integer,
    category character varying(100) NOT NULL,
    budgeted_amount numeric(15,2),
    actual_amount numeric(15,2),
    variance numeric(15,2),
    period date,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.budget_tracking OWNER TO mcpuser;

--
-- Name: budget_tracking_id_seq; Type: SEQUENCE; Schema: public; Owner: mcpuser
--

CREATE SEQUENCE public.budget_tracking_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.budget_tracking_id_seq OWNER TO mcpuser;

--
-- Name: budget_tracking_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mcpuser
--

ALTER SEQUENCE public.budget_tracking_id_seq OWNED BY public.budget_tracking.id;


--
-- Name: project_phases; Type: TABLE; Schema: public; Owner: mcpuser
--

CREATE TABLE public.project_phases (
    id integer NOT NULL,
    project_id integer,
    phase_name character varying(100) NOT NULL,
    phase_order integer,
    start_date date,
    end_date date,
    status character varying(50) DEFAULT 'planned'::character varying,
    budget numeric(15,2),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.project_phases OWNER TO mcpuser;

--
-- Name: project_phases_id_seq; Type: SEQUENCE; Schema: public; Owner: mcpuser
--

CREATE SEQUENCE public.project_phases_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.project_phases_id_seq OWNER TO mcpuser;

--
-- Name: project_phases_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mcpuser
--

ALTER SEQUENCE public.project_phases_id_seq OWNED BY public.project_phases.id;


--
-- Name: projects; Type: TABLE; Schema: public; Owner: mcpuser
--

CREATE TABLE public.projects (
    id integer NOT NULL,
    project_id character varying(50) NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    status character varying(50) DEFAULT 'active'::character varying,
    budget numeric(15,2),
    start_date date,
    end_date date,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.projects OWNER TO mcpuser;

--
-- Name: projects_id_seq; Type: SEQUENCE; Schema: public; Owner: mcpuser
--

CREATE SEQUENCE public.projects_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.projects_id_seq OWNER TO mcpuser;

--
-- Name: projects_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mcpuser
--

ALTER SEQUENCE public.projects_id_seq OWNED BY public.projects.id;


--
-- Name: quality_checks; Type: TABLE; Schema: public; Owner: mcpuser
--

CREATE TABLE public.quality_checks (
    id integer NOT NULL,
    project_id integer,
    check_date date NOT NULL,
    check_type character varying(100),
    component character varying(100),
    result character varying(50),
    inspector character varying(100),
    notes text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.quality_checks OWNER TO mcpuser;

--
-- Name: quality_checks_id_seq; Type: SEQUENCE; Schema: public; Owner: mcpuser
--

CREATE SEQUENCE public.quality_checks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.quality_checks_id_seq OWNER TO mcpuser;

--
-- Name: quality_checks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mcpuser
--

ALTER SEQUENCE public.quality_checks_id_seq OWNED BY public.quality_checks.id;


--
-- Name: resources; Type: TABLE; Schema: public; Owner: mcpuser
--

CREATE TABLE public.resources (
    id integer NOT NULL,
    project_id integer,
    resource_type character varying(50),
    resource_name character varying(100),
    quantity integer,
    unit_cost numeric(10,2),
    total_cost numeric(15,2),
    status character varying(50) DEFAULT 'available'::character varying,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.resources OWNER TO mcpuser;

--
-- Name: resources_id_seq; Type: SEQUENCE; Schema: public; Owner: mcpuser
--

CREATE SEQUENCE public.resources_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.resources_id_seq OWNER TO mcpuser;

--
-- Name: resources_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mcpuser
--

ALTER SEQUENCE public.resources_id_seq OWNED BY public.resources.id;


--
-- Name: safety_incidents; Type: TABLE; Schema: public; Owner: mcpuser
--

CREATE TABLE public.safety_incidents (
    id integer NOT NULL,
    project_id integer,
    incident_date date NOT NULL,
    incident_type character varying(100),
    severity character varying(50),
    description text,
    corrective_action text,
    reported_by character varying(100),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.safety_incidents OWNER TO mcpuser;

--
-- Name: safety_incidents_id_seq; Type: SEQUENCE; Schema: public; Owner: mcpuser
--

CREATE SEQUENCE public.safety_incidents_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.safety_incidents_id_seq OWNER TO mcpuser;

--
-- Name: safety_incidents_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mcpuser
--

ALTER SEQUENCE public.safety_incidents_id_seq OWNED BY public.safety_incidents.id;


--
-- Name: budget_tracking id; Type: DEFAULT; Schema: public; Owner: mcpuser
--

ALTER TABLE ONLY public.budget_tracking ALTER COLUMN id SET DEFAULT nextval('public.budget_tracking_id_seq'::regclass);


--
-- Name: project_phases id; Type: DEFAULT; Schema: public; Owner: mcpuser
--

ALTER TABLE ONLY public.project_phases ALTER COLUMN id SET DEFAULT nextval('public.project_phases_id_seq'::regclass);


--
-- Name: projects id; Type: DEFAULT; Schema: public; Owner: mcpuser
--

ALTER TABLE ONLY public.projects ALTER COLUMN id SET DEFAULT nextval('public.projects_id_seq'::regclass);


--
-- Name: quality_checks id; Type: DEFAULT; Schema: public; Owner: mcpuser
--

ALTER TABLE ONLY public.quality_checks ALTER COLUMN id SET DEFAULT nextval('public.quality_checks_id_seq'::regclass);


--
-- Name: resources id; Type: DEFAULT; Schema: public; Owner: mcpuser
--

ALTER TABLE ONLY public.resources ALTER COLUMN id SET DEFAULT nextval('public.resources_id_seq'::regclass);


--
-- Name: safety_incidents id; Type: DEFAULT; Schema: public; Owner: mcpuser
--

ALTER TABLE ONLY public.safety_incidents ALTER COLUMN id SET DEFAULT nextval('public.safety_incidents_id_seq'::regclass);


--
-- Data for Name: budget_tracking; Type: TABLE DATA; Schema: public; Owner: mcpuser
--

COPY public.budget_tracking (id, project_id, category, budgeted_amount, actual_amount, variance, period, created_at) FROM stdin;
1	1	Labor	800000.00	750000.00	\N	2024-09-01	2025-09-29 03:21:21.021424
2	1	Materials	1200000.00	1150000.00	\N	2024-09-01	2025-09-29 03:21:21.021424
3	1	Equipment	500000.00	480000.00	\N	2024-09-01	2025-09-29 03:21:21.021424
4	2	Labor	1500000.00	1450000.00	\N	2024-09-01	2025-09-29 03:21:21.021424
5	2	Materials	2500000.00	2400000.00	\N	2024-09-01	2025-09-29 03:21:21.021424
6	3	Labor	600000.00	580000.00	\N	2024-09-01	2025-09-29 03:21:21.021424
7	3	Materials	900000.00	850000.00	\N	2024-09-01	2025-09-29 03:21:21.021424
\.


--
-- Data for Name: project_phases; Type: TABLE DATA; Schema: public; Owner: mcpuser
--

COPY public.project_phases (id, project_id, phase_name, phase_order, start_date, end_date, status, budget, created_at) FROM stdin;
\.


--
-- Data for Name: projects; Type: TABLE DATA; Schema: public; Owner: mcpuser
--

COPY public.projects (id, project_id, name, description, status, budget, start_date, end_date, created_at, updated_at) FROM stdin;
1	PROJ-001	Downtown Office Complex	Modern office building construction	active	2500000.00	2024-01-15	2025-06-30	2025-09-29 03:21:21.014548	2025-09-29 03:21:21.014548
2	PROJ-002	Residential Tower	High-rise residential building	active	5000000.00	2024-03-01	2026-02-28	2025-09-29 03:21:21.014548	2025-09-29 03:21:21.014548
3	PROJ-003	Shopping Mall Renovation	Complete renovation of existing mall	active	1800000.00	2024-02-01	2024-11-30	2025-09-29 03:21:21.014548	2025-09-29 03:21:21.014548
\.


--
-- Data for Name: quality_checks; Type: TABLE DATA; Schema: public; Owner: mcpuser
--

COPY public.quality_checks (id, project_id, check_date, check_type, component, result, inspector, notes, created_at) FROM stdin;
\.


--
-- Data for Name: resources; Type: TABLE DATA; Schema: public; Owner: mcpuser
--

COPY public.resources (id, project_id, resource_type, resource_name, quantity, unit_cost, total_cost, status, created_at) FROM stdin;
1	1	Equipment	Excavator	2	50000.00	100000.00	available	2025-09-29 03:21:21.033215
2	1	Labor	Construction Workers	25	35000.00	875000.00	available	2025-09-29 03:21:21.033215
3	2	Equipment	Concrete Mixer	3	25000.00	75000.00	available	2025-09-29 03:21:21.033215
4	2	Labor	Skilled Labor	40	40000.00	1600000.00	available	2025-09-29 03:21:21.033215
5	3	Equipment	Painting Equipment	5	5000.00	25000.00	available	2025-09-29 03:21:21.033215
6	3	Labor	Renovation Crew	15	30000.00	450000.00	available	2025-09-29 03:21:21.033215
\.


--
-- Data for Name: safety_incidents; Type: TABLE DATA; Schema: public; Owner: mcpuser
--

COPY public.safety_incidents (id, project_id, incident_date, incident_type, severity, description, corrective_action, reported_by, created_at) FROM stdin;
1	1	2024-08-15	Slip and Fall	Minor	Worker slipped on wet floor in construction area	Improved floor signage and drainage	\N	2025-09-29 03:21:21.028676
2	2	2024-07-22	Equipment Malfunction	Moderate	Crane malfunction during lifting operation	Scheduled maintenance and operator retraining	\N	2025-09-29 03:21:21.028676
3	1	2024-09-05	Near Miss	Low	Worker nearly struck by falling debris	Enhanced PPE requirements and safety briefings	\N	2025-09-29 03:21:21.028676
\.


--
-- Name: budget_tracking_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mcpuser
--

SELECT pg_catalog.setval('public.budget_tracking_id_seq', 7, true);


--
-- Name: project_phases_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mcpuser
--

SELECT pg_catalog.setval('public.project_phases_id_seq', 1, false);


--
-- Name: projects_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mcpuser
--

SELECT pg_catalog.setval('public.projects_id_seq', 3, true);


--
-- Name: quality_checks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mcpuser
--

SELECT pg_catalog.setval('public.quality_checks_id_seq', 1, false);


--
-- Name: resources_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mcpuser
--

SELECT pg_catalog.setval('public.resources_id_seq', 6, true);


--
-- Name: safety_incidents_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mcpuser
--

SELECT pg_catalog.setval('public.safety_incidents_id_seq', 3, true);


--
-- Name: budget_tracking budget_tracking_pkey; Type: CONSTRAINT; Schema: public; Owner: mcpuser
--

ALTER TABLE ONLY public.budget_tracking
    ADD CONSTRAINT budget_tracking_pkey PRIMARY KEY (id);


--
-- Name: project_phases project_phases_pkey; Type: CONSTRAINT; Schema: public; Owner: mcpuser
--

ALTER TABLE ONLY public.project_phases
    ADD CONSTRAINT project_phases_pkey PRIMARY KEY (id);


--
-- Name: projects projects_pkey; Type: CONSTRAINT; Schema: public; Owner: mcpuser
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_pkey PRIMARY KEY (id);


--
-- Name: projects projects_project_id_key; Type: CONSTRAINT; Schema: public; Owner: mcpuser
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_project_id_key UNIQUE (project_id);


--
-- Name: quality_checks quality_checks_pkey; Type: CONSTRAINT; Schema: public; Owner: mcpuser
--

ALTER TABLE ONLY public.quality_checks
    ADD CONSTRAINT quality_checks_pkey PRIMARY KEY (id);


--
-- Name: resources resources_pkey; Type: CONSTRAINT; Schema: public; Owner: mcpuser
--

ALTER TABLE ONLY public.resources
    ADD CONSTRAINT resources_pkey PRIMARY KEY (id);


--
-- Name: safety_incidents safety_incidents_pkey; Type: CONSTRAINT; Schema: public; Owner: mcpuser
--

ALTER TABLE ONLY public.safety_incidents
    ADD CONSTRAINT safety_incidents_pkey PRIMARY KEY (id);


--
-- Name: idx_budget_tracking_project; Type: INDEX; Schema: public; Owner: mcpuser
--

CREATE INDEX idx_budget_tracking_project ON public.budget_tracking USING btree (project_id);


--
-- Name: idx_projects_dates; Type: INDEX; Schema: public; Owner: mcpuser
--

CREATE INDEX idx_projects_dates ON public.projects USING btree (start_date, end_date);


--
-- Name: idx_projects_status; Type: INDEX; Schema: public; Owner: mcpuser
--

CREATE INDEX idx_projects_status ON public.projects USING btree (status);


--
-- Name: idx_quality_checks_project; Type: INDEX; Schema: public; Owner: mcpuser
--

CREATE INDEX idx_quality_checks_project ON public.quality_checks USING btree (project_id);


--
-- Name: idx_resources_project; Type: INDEX; Schema: public; Owner: mcpuser
--

CREATE INDEX idx_resources_project ON public.resources USING btree (project_id);


--
-- Name: idx_safety_incidents_date; Type: INDEX; Schema: public; Owner: mcpuser
--

CREATE INDEX idx_safety_incidents_date ON public.safety_incidents USING btree (incident_date);


--
-- Name: projects update_projects_updated_at; Type: TRIGGER; Schema: public; Owner: mcpuser
--

CREATE TRIGGER update_projects_updated_at BEFORE UPDATE ON public.projects FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: budget_tracking budget_tracking_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mcpuser
--

ALTER TABLE ONLY public.budget_tracking
    ADD CONSTRAINT budget_tracking_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: project_phases project_phases_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mcpuser
--

ALTER TABLE ONLY public.project_phases
    ADD CONSTRAINT project_phases_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: quality_checks quality_checks_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mcpuser
--

ALTER TABLE ONLY public.quality_checks
    ADD CONSTRAINT quality_checks_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: resources resources_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mcpuser
--

ALTER TABLE ONLY public.resources
    ADD CONSTRAINT resources_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: safety_incidents safety_incidents_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mcpuser
--

ALTER TABLE ONLY public.safety_incidents
    ADD CONSTRAINT safety_incidents_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict oycNX7ZExLwkfh0x38yKpJgBWhmfDki554FsqrJrFGDJSmoXJeSZL7SHAPBGBIG

